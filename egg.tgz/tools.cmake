# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(link-checker src/link-checker.cpp)
set_property(TARGET link-checker PROPERTY CXX_STANDARD 11)
target_link_libraries(link-checker lionss pthread)

add_executable(build-debug src/build-debug.cpp)
set_property(TARGET build-debug PROPERTY CXX_STANDARD 11)
target_link_libraries(build-debug lionss pthread)

add_executable(watchos-build src/watchos-build.cpp)
set_property(TARGET watchos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(watchos-build lionss pthread)

add_executable(unused-includes src/unused-includes.cpp)
set_property(TARGET unused-includes PROPERTY CXX_STANDARD 11)
target_link_libraries(unused-includes lionss pthread)

add_executable(constexpr-tests src/constexpr-tests.cpp)
set_property(TARGET constexpr-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(constexpr-tests lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(strip-check src/strip-check.cpp)
set_property(TARGET strip-check PROPERTY CXX_STANDARD 11)
target_link_libraries(strip-check lionss pthread)

add_executable(race-tests src/race-tests.cpp)
set_property(TARGET race-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(race-tests lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(vulnerability-report src/vulnerability-report.cpp)
set_property(TARGET vulnerability-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vulnerability-report lionss pthread)

add_executable(numa-bench src/numa-bench.cpp)
set_property(TARGET numa-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(numa-bench lionss pthread)

add_executable(broken-links src/broken-links.cpp)
set_property(TARGET broken-links PROPERTY CXX_STANDARD 11)
target_link_libraries(broken-links lionss pthread)

add_executable(core-dump-test src/core-dump-test.cpp)
set_property(TARGET core-dump-test PROPERTY CXX_STANDARD 11)
target_link_libraries(core-dump-test lionss pthread)

add_executable(valgrind-memcheck src/valgrind-memcheck.cpp)
set_property(TARGET valgrind-memcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-memcheck lionss pthread)

add_executable(unity-build src/unity-build.cpp)
set_property(TARGET unity-build PROPERTY CXX_STANDARD 11)
target_link_libraries(unity-build lionss pthread)

add_executable(llvm-cov src/llvm-cov.cpp)
set_property(TARGET llvm-cov PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-cov lionss pthread)

add_executable(dependency-pin src/dependency-pin.cpp)
set_property(TARGET dependency-pin PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-pin lionss pthread)

add_executable(concepts-check src/concepts-check.cpp)
set_property(TARGET concepts-check PROPERTY CXX_STANDARD 11)
target_link_libraries(concepts-check lionss pthread)

add_executable(dependency-review src/dependency-review.cpp)
set_property(TARGET dependency-review PROPERTY CXX_STANDARD 11)
target_link_libraries(dependency-review lionss pthread)

add_executable(clang-format-check src/clang-format-check.cpp)
set_property(TARGET clang-format-check PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format-check lionss pthread)

add_executable(header-guards src/header-guards.cpp)
set_property(TARGET header-guards PROPERTY CXX_STANDARD 11)
target_link_libraries(header-guards lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(wasm32-build src/wasm32-build.cpp)
set_property(TARGET wasm32-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm32-build lionss pthread)

add_executable(static-binary src/static-binary.cpp)
set_property(TARGET static-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(static-binary lionss pthread)

add_executable(control-flow-integrity src/control-flow-integrity.cpp)
set_property(TARGET control-flow-integrity PROPERTY CXX_STANDARD 11)
target_link_libraries(control-flow-integrity lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(snapshot-tests src/snapshot-tests.cpp)
set_property(TARGET snapshot-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(snapshot-tests lionss pthread)

add_executable(idempotency-tests src/idempotency-tests.cpp)
set_property(TARGET idempotency-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(idempotency-tests lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

